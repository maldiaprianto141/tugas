package com.diman.tugas_gis;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.location_map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //  tambah koordinat marker
        LatLng luwuk = new LatLng (-0.9994941130439595, 122.78772792492003);
        LatLng nambo = new LatLng(-1.0845942511583846, 122.72880404259581);

//    atur ukuran marker
        int tinggi = 100;
        int lebar = 100;

        BitmapDrawable bitmapStart = (BitmapDrawable)getResources().getDrawable(R.drawable.noun_862185_cc);
        BitmapDrawable bitmapDes = (BitmapDrawable)getResources().getDrawable(R.drawable.noun_862185_cc);

        Bitmap s = bitmapStart.getBitmap();
        Bitmap d = bitmapDes.getBitmap();

        Bitmap markerStart = Bitmap.createScaledBitmap(s, lebar, tinggi, false);
        Bitmap markerDes = Bitmap.createScaledBitmap(d, lebar, tinggi, false);

//    tambahkan marker ke map
        mMap.addMarker(new MarkerOptions().position(luwuk).title("Marker in Polres Kab. banggai")
        .snippet("Ini salah satu kantor Polres Kab. Banggai")
        .icon(BitmapDescriptorFactory.fromBitmap(markerStart)));

        mMap.addMarker(new MarkerOptions().position(nambo).title("Marker in nambo bosaa'")
                .snippet("Ini kampung saya cahya dwiputra")
                .icon(BitmapDescriptorFactory.fromBitmap(markerDes)));

        mMap.addPolyline(new PolylineOptions().add(
                luwuk,
                new LatLng(-0.9989924948955785, 122.78827216877426),
                new LatLng(-0.9981664999999907, 122.78755333677275),
                new LatLng(-0.9968679272120227, 122.79085945268685),
                new LatLng(-1.0006219627067805, 122.79298213025879),
                new LatLng(-1.0016310910237984, 122.79413983651988),
                new LatLng(-1.0065580071623332, 122.79224001086065),
                new LatLng(-1.007478093087358, 122.79357582577728),
                new LatLng(-1.008338818394893, 122.79318992369026),
                new LatLng(-1.0096547823729993, 122.79410728209571),
                new LatLng(-1.029061245289951, 122.77967053454508),
                new LatLng(-1.0502442787169264, 122.76512298559817),
                new LatLng(-1.058596220956969, 122.75333527262568),
                new LatLng(-1.062914985458514, 122.74875619824961),
                new LatLng(-1.0711332649290846, 122.74373119644265),
                nambo
        ).width(10)
                .color(Color.BLUE));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(luwuk, 11.5f));
    }
}
